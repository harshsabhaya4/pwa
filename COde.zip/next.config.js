// next.config.js

/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  output:"export",
  images: {
    remotePatterns: [
      {
        protocol: 'https',
        hostname: 'assets.oregontool.com',
      },
    ],
  },
};

module.exports = nextConfig;
