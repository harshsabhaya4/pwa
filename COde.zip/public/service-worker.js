const CACHE_NAME = "offline-bw15-cache-v1";

// ✅ Only include real, accessible files — no broken links!
const OFFLINE_URLS =  [
    '/', // Home page
    '/manifest.json',
    '/icons/icon-192x192.png',
    '/icons/icon-512x512.png',
    // Videos & Images from preloadAssets
    'https://assets.oregontool.com/adaptivemedia/rendition?id=9fe548dc441e9fb005e6c3cba497aa4daa0a324b',
    'https://assets.oregontool.com/adaptivemedia/rendition?id=f143ee17a2c0e65389e2a672c0a7983c75a29a30',
    'https://assets.oregontool.com/adaptivemedia/rendition?id=dc8e0ea834cd3980dd806781910e91b16f73f94b',
    'https://assets.oregontool.com/adaptivemedia/rendition?id=42064576b4f01fce5ca373495922eefc03267b35',
    'https://assets.oregontool.com/adaptivemedia/rendition?id=87961fbfc2d88e81341399af9f77535258d8cf4f',
    'https://assets.oregontool.com/adaptivemedia/rendition?id=2373607ac3325a24c8b300e22d77ec466bfb5d31',
    'https://assets.oregontool.com/adaptivemedia/rendition?id=309e35718b4ab130eecb08feefa3fc95b71c9830',
  ];

self.addEventListener("install", (event) => {
  console.log("[SW] Install event");

  event.waitUntil(
    (async () => {
      const cache = await caches.open(CACHE_NAME);

      for (const url of OFFLINE_URLS) {
        try {
          const response = await fetch(url, { mode: 'no-cors' });
          if (response.ok || response.type === "opaque") {
            await cache.put(url, response);
            console.log(`[SW] Cached: ${url}`);
          } else {
            console.warn(`[SW] Skipped (bad response): ${url}`);
          }
        } catch (error) {
          console.warn(`[SW] Failed to cache: ${url}`, error);
        }
      }
    })()
  );

  self.skipWaiting();
});
